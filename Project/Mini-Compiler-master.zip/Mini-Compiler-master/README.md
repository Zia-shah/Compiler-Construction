# Mini-Compiler
C++ Mini Compiler using tools Lex and Yacc
#### Constructs implemented:
1. If-else 
2. Ternary
3. While-loop
4. For-loop
