#include<stdio.h>
void main()
{
        int a = 4 * 5 / 2;
        int b = a * 7;
        
        int c = a / b + 8 / 4;
        int d = a + b * c;
        b = 100 * 100 - d + c;
	
}

