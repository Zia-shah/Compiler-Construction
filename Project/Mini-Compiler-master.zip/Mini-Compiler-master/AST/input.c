#include<stdio.h>
void main()
{
        int a = 4 * 5 / 2;
        int b = a * 7;
        
        while( a>b ){
                a = a+1;
        }
        
        int x = 20*a;
        
        if( b <= x ){
                a = 10;
        }
        c = 10;
        a = 100;
        int i = 1;
		if( a > 0)
		{
			i = 2;
		}
	
	int y = a+b;
	
	(x < b) ? x = 10 : x=11;
	
}

